<?php session_start(); ?>
<?php require 'header.php'; ?>
<?php require 'db-connect.php'; ?>
<?php require 'cart.php'; ?>
<?php require 'footer.php'; ?>