<?php session_start(); ?>
<?php require 'header.php'; ?>
<?php require 'db-connect.php'; ?>
<?php require 'detalist.php'; ?>
<?php require 'footer.php'; ?>