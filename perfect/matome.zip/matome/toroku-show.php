<?php session_start(); ?>
<?php require 'header.php'; ?>
<?php require 'db-connect.php'; ?>
<?php require 'toroku.php'; ?>
<?php require 'footer.php'; ?>