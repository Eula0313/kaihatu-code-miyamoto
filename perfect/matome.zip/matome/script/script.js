const app = new Vue({
    el: '#right-column',
    data() {
        return {
            color: 'メール',
            size: 'S'
        };
    }
});