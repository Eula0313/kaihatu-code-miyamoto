<?php require 'header.php'; ?>
<p>ログアウトしますか</p>
<a href="logout-output.php">ログアウト</a>
<?php require 'footer.php'; ?>