<?php require 'header.php'; ?>
<?php require 'db-connect.php'; ?>
<?php require 'menu.php'; ?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title></title>
    <style>
        body {
        
            color: #fff;
        }
    </style>
</head>
<body>

    <?php require 'footer.php'; ?>
</body>
</html>
