<?php
    const server = "mysql311.phy.lolipop.lan";
    const dbname = "LAA1517481-huwacon";
    const user = "LAA1517481";
    const pass = "huwacon0921";

    $connect = 'mysql:host='. server . ';dbname='. dbname . ';charset=utf8';
?>