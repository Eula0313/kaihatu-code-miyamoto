<?php
     const SERVER = 'mysql310.phy.lolipop.lan';
     const DBNAME = 'LAA1517469-taskura';
     const USER ='LAA1517469';
     const PASS ='1234';
    $connect = 'mysql:host='. SERVER . ';dbname='. DBNAME . ';charset=utf8';
    $pdo=new PDO('mysql:host=mysql310.phy.lolipop.lan;dbname=LAA1517469-taskura;charset=utf8','LAA1517469','1234');

?>