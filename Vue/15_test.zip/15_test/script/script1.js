new Vue({
    el: '#app',
    data() {
        return {
            seminars: [
                {id: 1, label: "Vueで２日間"},
                {id: 2, label: "Vueで３日間"},
                {id: 3, label: "PHPで３日間"},
                {id: 4, label: "PHPで５日間"}
            ]
        };
    }
});
