new Vue({
    el: '#app',
    data() {
        return {
            fee:0,
            day:0,
            total:0
        };
    },
    methods: {
        increment() {
            this.day++;
        },
        decrement(){
            this.day--;
        },
        multiply(){
            this.total=this.fee*this.day;
            
        }
    }
});
