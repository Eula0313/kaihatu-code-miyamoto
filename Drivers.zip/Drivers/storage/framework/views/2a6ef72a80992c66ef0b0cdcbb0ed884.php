<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/balance.css')); ?>">
    <title>月別収支詳細</title>
</head>
<body>
    <?php echo $__env->make('homebudget.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="details-container">
        <h1><?php echo e($year); ?>年 <?php echo e($month); ?>月の収支</h1>

        <!-- 前月と次月のボタン -->
        <div class="controls">
            <a href="<?php echo e(route('balance', ['month' => $month == 1 ? 12 : $month - 1, 'year' => $month == 1 ? $year - 1 : $year])); ?>" class="control-btn">◀ 前月</a>
            <a href="<?php echo e(route('balance', ['month' => $month == 12 ? 1 : $month + 1, 'year' => $month == 12 ? $year + 1 : $year])); ?>" class="control-btn">次月 ▶</a>
        </div>

        <div class="summary">
            <div class="income">+ <?php echo e(number_format($totalIncome)); ?> 円</div>
            <div class="expenditure">- <?php echo e(number_format(abs($totalExpenditure))); ?> 円</div>
        </div>
        <div class="balance">計 <?php echo e(number_format($balance)); ?> 円</div>
        
        <?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="entry">
                <div class="date"><?php echo e($entry->date); ?></div>
                <div class="user"><?php echo e(htmlspecialchars($entry->user_name)); ?></div>
                <div class="amount">
                    <?php if($entry->price > 0): ?>
                        <span class="income-amount">+ <?php echo e(number_format($entry->price)); ?></span>
                    <?php else: ?>
                        <span class="expenditure-amount">- <?php echo e(number_format(abs($entry->price))); ?></span>
                    <?php endif; ?>
                </div>
                <div class="category"><?php echo e(htmlspecialchars($entry->details)); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Drivers\resources\views/Homebudget/balance.blade.php ENDPATH**/ ?>