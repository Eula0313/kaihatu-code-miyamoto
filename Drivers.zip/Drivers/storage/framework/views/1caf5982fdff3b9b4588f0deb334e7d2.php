<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/setting.css')); ?>">
    <title>設定確認 - 家計簿アプリ</title>
</head>
<body>
    <h1>設定確認</h1>

    <?php if(session('confirmation')): ?>
        <div class="setting-container">
            <h2>設定内容を確認してください</h2>
            <?php if(session()->has('name')): ?>
                <p>名前: <?php echo e(session('name')); ?></p>
                <p>支出の上限: <?php echo e(number_format(session('limit'))); ?> 円</p>
                <p>貯金の目標: <?php echo e(number_format(session('savings'))); ?> 円</p>
            <?php endif; ?>
            <?php if(session()->has('group_name')): ?>
                <p>グループ名: <?php echo e(session('group_name')); ?></p>
                <p>グループの支出の上限: <?php echo e(number_format(session('group_limit'))); ?> 円</p>
                <p>グループの貯金の目標: <?php echo e(number_format(session('group_savings'))); ?> 円</p>
            <?php endif; ?>
            <form action="<?php echo e(route('setting.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit">設定を保存</button>
            </form>
        </div>
    <?php else: ?>
        <p>エラーが発生しました。もう一度お試しください。</p>
    <?php endif; ?>

    <!-- エラー表示 -->
    <?php if(session('exception')): ?>
    <div class="error-container">
        <h3>エラー詳細:</h3>
        <p><?php echo e(session('exception')->getMessage()); ?></p>
        <pre><?php echo e(session('exception')->getTraceAsString()); ?></pre>
    </div>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Drivers\resources\views/homebudget/setting_confirm.blade.php ENDPATH**/ ?>