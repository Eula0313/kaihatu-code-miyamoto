<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/setting.css')); ?>">
    <title>設定画面 - 家計簿アプリ</title>
    <script>
        function switchTab(tab) {
            document.querySelectorAll('.tab').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.setting-container').forEach(el => el.classList.remove('active'));

            document.getElementById(tab).classList.add('active');
            document.querySelector(`.${tab}-container`).classList.add('active');
        }
    </script>
    <style>
        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .tab {
            padding: 10px 20px;
            cursor: pointer;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 5px;
        }

        .tab.active {
            background-color: #007bff;
            color: #fff;
        }

        .setting-container {
            display: none;
        }

        .setting-container.active {
            display: block;
        }
    </style>
</head>
<body>
    <h1>設定</h1>

    <div class="tabs">
        <div class="tab active" id="personal" onclick="switchTab('personal')">個人設定</div>
        <div class="tab" id="group" onclick="switchTab('group')">グループ設定</div>
    </div>

    <!-- 個人設定フォーム -->
    <div class="setting-container personal-container active">
        <form action="<?php echo e(route('setting.confirm')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="setting-form-group">
                <label for="name">個人の名前</label>
                <input type="text" id="name" name="name" 
                       value="<?php echo e(session('name', '')); ?>" placeholder="名前を入力" required>
            </div>
            <div class="setting-form-group">
                <label for="limit">支出の上限 (円)</label>
                <input type="text" id="limit" name="limit" 
                       value="<?php echo e(session('limit', '')); ?>" placeholder="上限金額を入力" required>
            </div>
            <div class="setting-form-group">
                <label for="savings">貯金の目標 (円)</label>
                <input type="text" id="savings" name="savings" 
                       value="<?php echo e(session('savings', '')); ?>" placeholder="目標金額を入力" required>
            </div>
            <button type="submit">確認</button>
        </form>
    </div>

    <!-- グループ設定フォーム -->
    <div class="setting-container group-container">
        <form action="<?php echo e(route('setting.confirm')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="setting-form-group">
                <label for="group_name">グループの名前</label>
                <input type="text" id="group_name" name="group_name" 
                       value="<?php echo e(session('group_name', '')); ?>" placeholder="グループ名を入力" required>
            </div>
            <div class="setting-form-group">
                <label for="group_limit">グループの支出の上限 (円)</label>
                <input type="text" id="group_limit" name="group_limit" 
                       value="<?php echo e(session('group_limit', '')); ?>" placeholder="上限金額を入力" required>
            </div>
            <div class="setting-form-group">
                <label for="group_savings">グループの貯金の目標 (円)</label>
                <input type="text" id="group_savings" name="group_savings" 
                       value="<?php echo e(session('group_savings', '')); ?>" placeholder="目標金額を入力" required>
            </div>
            <button type="submit">確認</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Drivers\resources\views/homebudget/setting.blade.php ENDPATH**/ ?>