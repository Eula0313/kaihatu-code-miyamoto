<?php

return [
    'date' => '日付で入力してください。',
    'numeric' => '数値で入力してください。',
    'required' => '必須項目です。',
];